import requests
import json
import re
import os







# different prompt base on different choice
def choice_to_prompt(choice):
    choice_range = ["A","B","C","D"]
    if choice not in choice_range:
        return "Invalid choice"
    prompt1 = "你是一位专业的文献阅读者，接下来我将传入一段多个文献的内容，不同文献之间将使用'====================='进行分割，请你使用中文给出基于这些文献的大模型对话。"
    prompt2 = "你是一位专业的文献概括者，接下来我将传入一段文献的内容，请你使用中文对该文献文件进行 summary。"
    prompt3 = "你是一位专业的文献翻译者，接下来我将传入一段英文文献内容，请你对该文献文件进行翻译为中文的工作。如果该文献内容是中文，请你仅需要返回'文献已是中文'即可。"
    prompt4 = "你是一位专业的文献综述学者，接下来我将传入一段多个文献的内容，不同文献之间将使用'====================='进行分割，请你使用中文对这些文献进行综述。"
    if choice == "A":
        return prompt1
    elif choice == "B":
        return prompt2
    elif choice == "C":
        return prompt3
    else:
        return prompt4




# Function to process each directory and file
def process(input_file, choice, input_file_list):
    url_chat = "http://10.202.94.52:20232/api/chat"
    prompt = choice_to_prompt(choice)
    content = ""
    if input_file_list=="no":
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()
            # print(content)

    elif input_file == "no":
        directory = input_file_list
        for file_name in os.listdir(directory):
            file_path = os.path.join(directory, file_name)
            
            if os.path.isfile(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    content += "=====================\n\n"
                    content += f.read()  # 读取文件内容
                    content += "=====================\n\n"

    
    
    message =  prompt  +"\n" + content 

    with open("message.txt", "w") as f:
        f.write(message)

    # print(message)


    data = {
        "model": "qwq:latest",
        "messages": [
            {
                "role": "user",
                "content": f"{message}"
            }
        ],
        "stream": False
    }

    # Send request to the chat API
    response = requests.post(url_chat, json=data)
    response_dict = json.loads(response.text)

    content = response_dict.get('message', {}).get('content', "")

    # Define pattern to extract answer
    pattern = r'(?<=<\/think>\n\n)(.*)'

    match = re.search(pattern, content, re.DOTALL)

    if match:
        print("Your answer:")
        print(match.group(1))
        final_response = match.group(1)
        os.system("touch response.txt")
        with open("response.txt", "w") as f:
            f.write(final_response)
    else:
        print("No data received!")
        final_response = "No result found"

    # print(content)





